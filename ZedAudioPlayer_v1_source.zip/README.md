# Zed Audio Player

A first working Android music player that scans music stored on the phone and supports:

- Play / pause
- Previous / next
- Background playback through Media3
- Media notification / lock-screen controls supplied by MediaSessionService
- Local phone music library scanning
- Android 13+ audio permission handling

## Build on an Android phone

Recommended phone-only route: AndroidIDE.

1. Install AndroidIDE from its official project/source.
2. Extract this project.
3. Open the `ZedAudioPlayer` folder in AndroidIDE.
4. Allow Gradle to download dependencies.
5. Sync/build the project.
6. Install the generated debug APK on the phone.
7. Grant music/audio permission when Zed Audio starts.

## Project versions

- Android Gradle Plugin 9.4.0
- Gradle 9.6
- Kotlin 2.3.21
- Media3 1.11.0
- Compile/target SDK 37
- Minimum Android 8.0 (API 26)

## Next features

Planned next: search, playlists, favorites, shuffle/repeat, album artwork, equalizer, sleep timer, and a polished custom theme/logo.
