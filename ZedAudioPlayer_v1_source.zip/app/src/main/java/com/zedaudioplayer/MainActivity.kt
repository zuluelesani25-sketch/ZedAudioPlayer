package com.zedaudioplayer

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: Uri
)

class MainActivity : android.app.Activity() {

    private lateinit var listView: ListView
    private lateinit var nowPlaying: TextView
    private lateinit var playButton: Button
    private lateinit var controllerFuture: ListenableFuture<MediaController>
    private var controller: MediaController? = null
    private val songs = mutableListOf<Song>()

    private val permissionRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestAudioPermissionIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 12)
            setBackgroundColor(0xFF101010.toInt())
        }

        val title = TextView(this).apply {
            text = "ZED AUDIO"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 10, 0, 6)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "Your music, your way"
            textSize = 14f
            setTextColor(0xFFBDBDBD.toInt())
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))

        listView = ListView(this).apply {
            dividerHeight = 1
            divider = null
        }
        root.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 8)
            setBackgroundColor(0xFF1B1B1B.toInt())
        }

        nowPlaying = TextView(this).apply {
            text = "Nothing playing"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 10)
        }
        panel.addView(nowPlaying, LinearLayout.LayoutParams(-1, -2))

        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
        }

        val previous = Button(this).apply { text = "⏮" }
        playButton = Button(this).apply { text = "▶" }
        val next = Button(this).apply { text = "⏭" }

        controls.addView(previous, LinearLayout.LayoutParams(0, 52, 1f))
        controls.addView(playButton, LinearLayout.LayoutParams(0, 52, 1f))
        controls.addView(next, LinearLayout.LayoutParams(0, 52, 1f))
        panel.addView(controls)

        root.addView(panel, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)

        listView.setOnItemClickListener { _, _, position, _ ->
            playSong(position)
        }
        previous.setOnClickListener { controller?.seekToPreviousMediaItem() }
        next.setOnClickListener { controller?.seekToNextMediaItem() }
        playButton.setOnClickListener {
            controller?.let {
                if (it.isPlaying) it.pause() else it.play()
                updateControls()
            }
        }
    }

    private fun requestAudioPermissionIfNeeded() {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(permission), permissionRequest)
        } else {
            initializePlayerAndLoadMusic()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            initializePlayerAndLoadMusic()
        } else {
            Toast.makeText(this, "Music permission is required to show your songs.", Toast.LENGTH_LONG).show()
        }
    }

    private fun initializePlayerAndLoadMusic() {
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updateControls()
                }

                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    nowPlaying.text = mediaItem?.mediaMetadata?.title ?: "Nothing playing"
                }
            })
            loadMusic()
        }, com.google.common.util.concurrent.MoreExecutors.directExecutor())
    }

    private fun loadMusic() {
        songs.clear()

        val collection = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.IS_MUSIC
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        contentResolver.query(collection, projection, selection, null, sortOrder)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown title"
                val artist = cursor.getString(artistCol) ?: "Unknown artist"
                val uri = Uri.withAppendedPath(collection, id.toString())
                songs.add(Song(id, title, artist, uri))
            }
        }

        val adapter = object : ArrayAdapter<Song>(
            this, android.R.layout.simple_list_item_2, android.R.id.text1, songs
        ) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val song = getItem(position)!!
                view.findViewById<TextView>(android.R.id.text1).apply {
                    text = song.title
                    setTextColor(0xFFFFFFFF.toInt())
                    textSize = 16f
                }
                view.findViewById<TextView>(android.R.id.text2).apply {
                    text = song.artist
                    setTextColor(0xFFBDBDBD.toInt())
                }
                view.setBackgroundColor(0xFF101010.toInt())
                return view
            }
        }
        listView.adapter = adapter

        if (songs.isEmpty()) {
            Toast.makeText(this, "No music files were found on this phone.", Toast.LENGTH_LONG).show()
        }
    }

    private fun playSong(position: Int) {
        val c = controller ?: return

        val items = songs.map {
            MediaItem.Builder()
                .setUri(it.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(it.title)
                        .setArtist(it.artist)
                        .build()
                )
                .build()
        }

        c.setMediaItems(items, position, 0L)
        c.prepare()
        c.play()
        nowPlaying.text = songs[position].title
        updateControls()
    }

    private fun updateControls() {
        playButton.text = if (controller?.isPlaying == true) "⏸" else "▶"
    }

    override fun onDestroy() {
        controller?.release()
        super.onDestroy()
    }
}
